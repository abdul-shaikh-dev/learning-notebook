# Release evidence workbook

Visual companions in the notebook: [Source-to-user release checks](https://abdul-shaikh-dev.github.io/learning-notebook/index.html#topic/delivery-operations/release-contract). The original text traces below remain available for offline use.


## Foundation: observable local service
Record Python/tool versions and the local test outcomes, including the bounded artifact-startup failure case. Draw source→tests→artifact→config→process→user request. List the loopback/data boundaries and one invariant. Capture /version, /live, /ready and a synthetic note create/read. Explain what the checksum does and does not prove.

## Intermediate: candidate and rollback
Run `python distinct_artifact_drill.py` first. Record the two source hashes, candidate readiness denial, admitted note-read SLI counts and retained note after v1 rollback. Explain why the unchanged SQLite schema permits this rollback. Record Docker availability; if absent, mark commands reviewed only. If opted in, build the actual Dockerfile, inspect user/health, run v1 and a separately changed compatible v2 image, record image identity and smoke results. Classify application/config/schema changes and state rollback feasibility. Optionally complete the React/.NET/SQL integration plan after its language/data prerequisites; never label the Python stand-in as the full stack.

## Advanced: operational packet
SLI: eligible events, good outcome, source, window, target and release attribution.
Workload: environment, arrival model, payload, dataset, count/concurrency, errors and latency samples.
Recovery: snapshot identity/time, isolation target, integrity/business assertions, observed recovery duration and missing writes.
Incident: time→observation→decision→effect; separate observed cause from hypothesis.
Release record: source, artifact digest, config revision, schema range, gate, prior artifact, recovery owner.

At a 99.9% success target, 10,000 eligible requests allow 10 bad outcomes. Twelve bad outcomes exceed that budget by 2 and consume 1.2 times the allowance. Counter interval from 100/2 to 220/5 is 120 requests and 3 bad, giving 2 requests/s and 2.5% bad over 60 seconds. A snapshot containing A before B was written restores A, not B. The same-code v1/v2 label restart test proves only unchanged-schema persistence; actual differing-artifact rollback is a separate exercise.

For each claim write: mechanism; named executed check; observed result; environment/runtime; untested boundary; next experiment. These results describe the lab. They do not certify a production system.
