# A feasible study day

Plan a fictional day with limited time and a specific result to finish.

## Deliverables

- List fixed commitments and calculate remaining capacity.
- Select two outcomes and finish conditions.
- Include transitions, recovery and uncertainty.
- Write a return cue for one interrupted session.

## Assessment

Use these criteria to check your answer and choose what to revisit. A score is optional, and no completed worksheet is required to keep reading. This practice does not award a professional certification.

- Capacity calculation includes essential commitments and transitions.
- Two session outcomes have observable finish conditions.
- The schedule protects essential recovery and keeps uncertainty visible.
- An interruption record includes a usable next-step cue.

## Worked synthetic approach

For 240 available minutes, reserve 90 for essentials and transitions, 90 for a checked draft, 30 for practice and 30 for uncertainty. Optional formatting moves to another day. Record actual use without treating necessary care as failure. Return cue: draft.md, paragraph two checked; next verify paragraph three against the booking email.

## Your evidence

Outcome: __________

Constraints: __________

Decision record: __________

Result and limitations: __________

Next revision: __________
