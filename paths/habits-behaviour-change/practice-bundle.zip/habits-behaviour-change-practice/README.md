# Habits & Behaviour Change: printable practice

Extract the bundle into `habits-behaviour-change-practice`. All files are flat in this folder. Open Markdown in a text editor or print it from a Markdown viewer. No software runtime, account or internet is needed for the exercises. Source links need internet when you choose to read them.

Start with lessons 1–7 and foundation-project.md; continue with 8–14 and intermediate-project.md, then 15–20 and advanced-project.md. Each numbered worksheet has a blank response area, a fictional worked answer and a self-check. Keep originals and create your own copies. Use fictional cases if you prefer; sharing personal notes is optional.

This is everyday self-management and communication education. It does not assess mental health, provide therapy or diagnose anyone. The examples describe study, household and volunteer tasks. People have different resources and constraints; a missed action or unresolved disagreement is information, not a moral failure.

Manual verification: check that each worksheet is readable, fill in one fictional response, and compare it with the criteria. Completing a worksheet does not prove a habit has formed or another person will respond as hoped. See sources-and-limits.md for research boundaries.

## Interactive practice studio

Open `lab.html` in a browser with `lab.js`, `lab-model.js` and `lab.css` beside it. No installation, account or external service is required. Use the five activity buttons for capacity planning, a keyboard-accessible task board, a habit experiment, a recall card and a conversation scenario.

These are educational models: the capacity sketch does not schedule overlapping appointments; a chosen review date does not create a reminder; a conversation opening cannot guarantee agreement. All entries stay in page memory and reload clears them. Use **Export my practice** to keep a private JSON copy. **Restore an exported practice file** validates and previews it before you choose **Replace page entries**. This restores all five activities without a server or automatic sync. Older exports restore an equivalent capacity result, but you should review the reconstructed buffer percentage and disruption input. The notebook backlink works in the hosted site; from an extracted kit it may not resolve, and you can return to the notebook using your own bookmark.

## Optional connected case

These lessons follow one evolving situation. Read the worked case first; try a changed case aloud or in your own tools when useful. No extra worksheet or written submission is required. These fictional cases provide reasoning practice, not a validated assessment.

- **4. Map the cue and surrounding context** (`cue-map`): One routine, two different opportunities.
- **16. Change one practical element at a time** (`one-change-test`): Separate a useful change from a good week.
- **17. Rebuild the plan when the environment changes** (`changed-context`): Keep the purpose when the cue disappears.
