# Learning How to Learn: printable practice

No software, account or technical knowledge is required. Print these Markdown files, read them in any text viewer, or copy their tables into a notebook. Keep every file together after extracting the bundle. A filled sample is synthetic evidence, never your result.

Suggested task order:

1. Read lessons 1–6 and complete tasks 1–5 in foundation-kit.md. Write in practice-log.md before opening the sample answers.
2. Read lessons 7–15 and complete tasks 1–6 in intermediate-kit.md. Keep the original attempts and correction notes.
3. Read lessons 16–20 and complete tasks 1–6 in advanced-kit.md. A delayed attempt must actually happen; until then mark it pending.
4. Use the four project criteria to check your attempt. Revisit anything missing or unclear. You can answer aloud or in a short note; a score is optional. Keep an attempt made after a gap distinct from one made immediately.

Files: foundation-kit.md has the fictional policy, baseline and answer key; intermediate-kit.md builds a feasible schedule and repairs errors; advanced-kit.md supplies changed-context cases and the final portfolio; practice-log.md provides blank and filled sheets; research-and-limits.md provides primary links and careful boundaries. The course diagrams are available in the lessons; practice remains usable without them.

Suggested pace: one small lesson or attempt when available. These are learning opportunities, not fixed daily requirements. Choose paper-friendly, low-risk material for your own topic and verify its answers. Use your actual dates and results. Do not convert the synthetic policy into workplace advice.

## Interactive practice studio

Open `lab.html` in a browser with `lab.js`, `lab-model.js` and `lab.css` beside it. No installation, account or external service is required. Use the five activity buttons for capacity planning, a keyboard-accessible task board, a habit experiment, a recall card and a conversation scenario.

These are educational models: the capacity sketch does not schedule overlapping appointments; a chosen review date does not create a reminder; a conversation opening cannot guarantee agreement. All entries stay in page memory and reload clears them. Use **Export my practice** to keep a private JSON copy. **Restore an exported practice file** validates and previews it before you choose **Replace page entries**. This restores all five activities without a server or automatic sync. Older exports restore an equivalent capacity result, but you should review the reconstructed buffer percentage and disruption input. The notebook backlink works in the hosted site; from an extracted kit it may not resolve, and you can return to the notebook using your own bookmark.

## Optional connected case

These lessons follow one evolving situation. Read the worked case first; try a changed case aloud or in your own tools when useful. No extra worksheet or written submission is required. These fictional cases provide reasoning practice, not a validated assessment.

- **8. Move from worked examples to independent attempts** (`worked-to-independent`): Try the same decision with less help.
- **5. Return after a gap** (`spaced-returns`): Use a later occasion to discover what remains.
- **16. Test transfer with changed cases** (`transfer-cases`): Check whether the setting, rule or available information has changed.
